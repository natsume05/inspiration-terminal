# 🚀 灵感传输终端 (Inspiration Terminal)

![Status](https://img.shields.io/badge/Status-Active-success) ![PHP](https://img.shields.io/badge/PHP-8.0+-777BB4) ![Style](https://img.shields.io/badge/Style-Outer%20Wilds-blue)

> “无论代价如何，在此刻下你的思想……”

这是一个集成了**博客**、**工具箱**与**匿名社区**的个人门户网站。作为我的全栈开发入门项目，它融合了《星际拓荒》、《空洞骑士》与《原神》的视觉风格。

## ✨ 功能特性 (Features)

### 🌌 虚空梦语 (社区版块)
- **匿名发帖**：基于 MySQL 数据库的留言板机制。
- **互动系统**：支持点赞（心跳特效）、评论（折叠/展开）与链接分享。
- **人性化体验**：由 PHP 后端处理的“几分钟前”时间显示算法。
- **权限管理**：管理员账号拥有删帖权限。

### 👤 个人中心 (Profile)
- **身份系统**：完整的注册/登录流程，含图形验证码。
- **隐私空间**：加密存储的私人笔记功能。
- **档案管理**：支持修改头像、签名与个人信息。

### 🛠️ 提瓦特百宝箱
- 实用工具导航聚合，动态分类切换。

## 📸 预览 (Screenshots)
![主页](assets/images/image.png)
![深空日志](assets/images/image-1.png)
![提瓦特百宝箱](assets/images/image-2.png)
![虚空梦语](assets/images/image-3.png)


## 🛠️ 技术栈 (Tech Stack)

- **Frontend**: HTML5, CSS3 (Flexbox/Grid), Vanilla JS
- **Backend**: Native PHP (无框架纯手写)
- **Database**: MySQL / MariaDB
- **Environment**: XAMPP (Local), cPanel (Production)

## 📝 开发日志 (Dev Log)

- **2026.02.07** - 成功完成本地化部署 (XAMPP)，解决数据库编码与时区问题。
- **2026.02.06** - 实现用户登录与图形验证码系统。
- **2026.02.05** - 初步完成《空洞骑士》风格 UI 设计。

---
*Created by [MingMo](https://github.com/natsume05)*