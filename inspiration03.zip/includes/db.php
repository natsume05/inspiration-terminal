<?php
// db.php - 本地开发环境配置

// 1. 本地也要设置时区
date_default_timezone_set('Asia/Shanghai');

$servername = "localhost";
$username   = "root";      // XAMPP 默认用户名
$password   = "";          // XAMPP 默认密码是空的 (双引号中间什么都别填)
$dbname     = "my_forum";  // 刚才你在本地 phpMyAdmin 建的库名

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("数据库连接失败: " . $conn->connect_error);
}

// 2. MySQL 端：强制将数据库会话设为 +8 时区 (解决 13h 时差的核心！)
$conn->query("SET time_zone = '+08:00'");

// 3. 字符集
$conn->set_charset("utf8mb4");

// 4. 开启 Session
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// --- 人性化时间函数 ---
function time_ago($timestamp) {
    if (empty($timestamp)) return "未知时间";
    
    $time_ago = strtotime($timestamp);
    $current_time = time();
    $time_difference = $current_time - $time_ago;
    $seconds = $time_difference;
    
    $minutes = round($seconds / 60);
    $hours   = round($seconds / 3600);
    $days    = round($seconds / 86400);
    $weeks   = round($seconds / 604800);
    $months  = round($seconds / 2629440);
    $years   = round($seconds / 31553280);

    if($seconds <= 60) return "刚刚";
    else if($minutes <= 60) return $minutes."分钟前";
    else if($hours <= 24) return $hours."小时前";
    else if($days <= 7) return $days."天前";
    else if($weeks <= 4.3) return $weeks."周前";
    else if($months <= 12) return $months."月前";
    else return $years."年前";
}
?>